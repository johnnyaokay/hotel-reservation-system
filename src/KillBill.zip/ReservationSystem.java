import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ReservationSystem {
	private Scanner in = new Scanner(System.in);
	private ArrayList<Hotel> Hotels = new ArrayList<>();
	private ArrayList<Reservation> Reservations = new ArrayList<>();
	private int minAdults;
	private int maxAdults;
	private int minChildren;
	private int maxChildren;
	
	public Reservation getReservation(String ReservationNumber){
		for(int i = 0; i < Reservations.size(); i++) {
			if(ReservationNumber.equals(Reservations.get(i).getReservationNumber())) {
				return Reservations.get(i);
			}
		}
		return null;
	}
	
	public int getMinAdults() {
		return minAdults;
	}
	
	public int getMaxAdults() {
		return maxAdults;
	}
	
	public int getMinChildren() {
		return minChildren;
	}
	
	public int getMaxChildren() {
		return maxChildren;
	}

	//only display if room is available for check-in/check-out days
	public Room getRoomChoices(int noOfAdults, int noOfChildren, ReservationDate checkIn, ReservationDate checkOut) {
		HashMap<Integer, Room> roomIndexes = new HashMap<Integer, Room>();
		int day = checkIn.getWeekday();
		int roomCount = 0;
		for(int i = 0; i < Hotels.size(); i++) {
			ArrayList<Room> hotelRooms = Hotels.get(i).getRooms();
			for(int j = 0; j < hotelRooms.size(); j++) {
				Room room =  hotelRooms.get(j);
				if(room.canOccupy(noOfAdults, noOfChildren)){
					roomCount++;
					System.out.println("(" + (roomCount) + ")" + room + "| " +  room.getRates()[day]);
					roomIndexes.put(roomCount, room);
				}
			}
		}
		int command = in.nextInt();
		return roomIndexes.get(command);
	}
	
	public void addReservation(Reservation reservation) {
		Reservations.add(reservation);
	}
	
	public void loadData() throws IOException {
		//Hotel type                  = 0
		//Room type                   = 1
		//Number of Rooms             = 2
		//Occupancy Min Adult + Child = 3
		//Occupancy Max Adult + Child = 4
		//Rates Monday-Sunday         = 5-11
		
		
		String fileIn = "src/l4hotels.csv";
	    String line = null;
	    int lineNumber = 1;
	    Hotel currentHotel = null;
	    
		FileReader fileReader = new FileReader(fileIn);
	    BufferedReader bufferedReader = new BufferedReader(fileReader);

	    while ((line = bufferedReader.readLine()) != null) {
	    	if(lineNumber > 2) {
	    		String[] values = line.split(",");
	    		String[] minOccupancies = values[3].split("\\+");
	    		String[] maxOccupancies = values[4].split("\\+");
	    		
	    		int minAdultOccupancy = Integer.parseInt(minOccupancies[0]);
    			int maxAdultOccupancy = Integer.parseInt(maxOccupancies[0]);
    			int minChildOccupancy = Integer.parseInt(minOccupancies[1]);
    			int maxChildOccupancy = Integer.parseInt(maxOccupancies[1]);
    			double[] rates = new double[7];
    			for(int i = 5; i < values.length; i++) {
    			    rates[i - 5] = Double.parseDouble(values[i]);
    			}
    			
	    		if(!values[0].equals("")) {
	    			currentHotel = new Hotel(values[0]);
	    			Hotels.add(currentHotel);
	    		}
	    		currentHotel.addRoom(values[1], Integer.parseInt(values[2]), minAdultOccupancy, maxAdultOccupancy, minChildOccupancy, maxChildOccupancy, rates);
	    		
	    		if(minAdultOccupancy > minAdults) minAdults = minAdultOccupancy;
	    		if(maxAdultOccupancy > maxAdults) maxAdults = maxAdultOccupancy;
	    		if(minChildOccupancy > minChildren) minChildren = minChildOccupancy;
	    		if(maxChildOccupancy > maxChildren) maxChildren = maxChildOccupancy;
	    	}
	        lineNumber++;
	    }
	    bufferedReader.close();
	}
}
