
public class ReservedRoom {
	private Room room;
	private int noOfAdults;
	private int noOfChildren;
	private double price;
	private Boolean breakfastIncluded = false;
	
	public ReservedRoom(Room room, int noOfAdults, int noOfChildren, double price) {
		this.room = room;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.price = price;
	}

	public Room getRoom() {
		return room;
	}

	public double getPrice() {
		return price;
	}

	public Boolean getBreakfastIncluded() {
		return breakfastIncluded;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}
	
	
}
	
