import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ReservationSystem {
	private Scanner in = new Scanner(System.in);
	private ArrayList<Hotel> Hotels = new ArrayList<>();
	private ArrayList<Reservation> Reservations = new ArrayList<>();
	private int minAdults;
	private int maxAdults;
	private int minChildren;
	private int maxChildren;
	
	
	public Reservation getReservation(String ReservationNumber){
		for(int i = 0; i < Reservations.size(); i++) {
			if(ReservationNumber.equals(Reservations.get(i).getReservationNumber())) {
				return Reservations.get(i);
			}
		}
		return null;
	}
	
	public int getMinAdults() {
		return minAdults;
	}
	
	public int getMaxAdults() {
		return maxAdults;
	}
	
	public int getMinChildren() {
		return minChildren;
	}
	
	public int getMaxChildren() {
		return maxChildren;
	}
	
	public Room getRoomByName(String name) {
		for(int i = 0; i < Hotels.size(); i++) {
			ArrayList<Room> hotelRooms = Hotels.get(i).getRooms();
			for(int j = 0; j < hotelRooms.size(); j++) {
				Room room =  hotelRooms.get(j);
				if(name.equals(room.getRoomType())){
					return room;
				}
			}
		}
		return null;
	}
	
	public double getRoomPrice(Room chosenRoom, ReservationDate checkIn, ReservationDate checkOut) {
		int noOfNights = checkIn.getNoOfNights(checkOut);
		double[] rates = chosenRoom.getRates();
		int currentDay = checkIn.getWeekday();
		double price = 0;
		for(int j = 0; j < noOfNights; j++) {
			price += rates[currentDay];
			currentDay++;
			if(currentDay == 7) currentDay = 0;
		}
		return price;
	}

	//only display if room is available for check-in/check-out days
	public Room getRoomChoices(int noOfAdults, int noOfChildren, ReservationDate checkIn, ReservationDate checkOut) {
		HashMap<Integer, Room> roomIndexes = new HashMap<Integer, Room>();
		int day = checkIn.getWeekday();
		int roomCount = 0;
		for(int i = 0; i < Hotels.size(); i++) {
			ArrayList<Room> hotelRooms = Hotels.get(i).getRooms();
			for(int j = 0; j < hotelRooms.size(); j++) {
				Room room =  hotelRooms.get(j);
				if(room.RoomsAvailable() && room.canOccupy(noOfAdults, noOfChildren)){
					roomCount++;
					System.out.println("(" + (roomCount) + ")" + room + "| " +  room.getRates()[day]);
					roomIndexes.put(roomCount, room);
				}
			}
		}
		int command = in.nextInt();
		return roomIndexes.get(command);
	}
	
	public void addReservation(Reservation reservation) {
		Reservations.add(reservation);
	}
	
	public void loadHotelData() throws IOException {
		//Hotel type                  = 0
		//Room type                   = 1
		//Number of Rooms             = 2
		//Occupancy Min Adult + Child = 3
		//Occupancy Max Adult + Child = 4
		//Rates Monday-Sunday         = 5-11
		
		
		String fileIn = "src/l4hotels.csv";
	    String line = null;
	    int lineNumber = 1;
	    Hotel currentHotel = null;
	    
		FileReader fileReader = new FileReader(fileIn);
	    BufferedReader bufferedReader = new BufferedReader(fileReader);

	    while ((line = bufferedReader.readLine()) != null) {
	    	if(lineNumber > 2) {
	    		String[] values = line.split(",");
	    		String[] minOccupancies = values[3].split("\\+");
	    		String[] maxOccupancies = values[4].split("\\+");
	    		
	    		int minAdultOccupancy = Integer.parseInt(minOccupancies[0]);
    			int maxAdultOccupancy = Integer.parseInt(maxOccupancies[0]);
    			int minChildOccupancy = Integer.parseInt(minOccupancies[1]);
    			int maxChildOccupancy = Integer.parseInt(maxOccupancies[1]);
    			double[] rates = new double[7];
    			for(int i = 5; i < values.length; i++) {
    			    rates[i - 5] = Double.parseDouble(values[i]);
    			}
    			
	    		if(!values[0].equals("")) {
	    			currentHotel = new Hotel(values[0]);
	    			Hotels.add(currentHotel);
	    		}
	    		currentHotel.addRoom(values[1], Integer.parseInt(values[2]), minAdultOccupancy, maxAdultOccupancy, minChildOccupancy, maxChildOccupancy, rates);
	    		
	    		if(minAdultOccupancy > minAdults) minAdults = minAdultOccupancy;
	    		if(maxAdultOccupancy > maxAdults) maxAdults = maxAdultOccupancy;
	    		if(minChildOccupancy > minChildren) minChildren = minChildOccupancy;
	    		if(maxChildOccupancy > maxChildren) maxChildren = maxChildOccupancy;
	    	}
	        lineNumber++;
	    }
	    bufferedReader.close();
	}
	
	public void loadReservationData() throws IOException {
		//Reservation Number = 0
		//Reservation Name   = 1
		//Reservation Type   = 2
		//Check-In Date      = 3
		//Nights             = 4 
		//Number Of Rooms    = 5
		//Rooms              = 6
		//Occupancy          = 7
		//Breakfast Included = 8
		//Total              = 9
		//Deposit            = 10
		
		
		String fileIn = "src/Reservation Information.csv";
	    String line = null;
	    int lineNumber = 1;
	    
		FileReader fileReader = new FileReader(fileIn);
	    BufferedReader bufferedReader = new BufferedReader(fileReader);

	    while ((line = bufferedReader.readLine()) != null) {
	    	if(lineNumber > 1) {
	    		String[] values = line.split(",");
	    		String ReservationNumber = values[0];
	    		String ReservationName = values[1];
	    		String ReservationType = values[2];
	    		int noOfNights = Integer.parseInt(values[4]);
	    		int noOfRooms = Integer.parseInt(values[5]);
	    		ReservationDate checkInDate = new ReservationDate(values[3]);
	    		ReservationDate checkOutDate = new ReservationDate(LocalDate.now().plusDays(noOfNights));		
	    		boolean breakfastIncluded = Boolean.parseBoolean(values[8]);
	    		double total = Double.parseDouble(values[9]);
	    		double deposit = Double.parseDouble(values[10]);
	    		Bill bill = new Bill(total);
	    	
	    		ArrayList<ReservedRoom> Rooms = new ArrayList<>();
	    		for(int i = 0; i < noOfRooms; i++) {
	    			String[] Occupancy = values[7].split("\\+");
		    		int noOfAdults = Integer.parseInt(Occupancy[0]);
		    		int noOfChildren = Integer.parseInt(Occupancy[1]);
		    		Room room = getRoomByName(values[5]);
		    		room.takeRoom();
		    		Rooms.add(new ReservedRoom(room, noOfAdults, noOfChildren));
		    		lineNumber++;
	    		}
	    		
	    		if (ReservationType.equals("Standard")) 
					Reservations.add(new StandardReservation(ReservationNumber, ReservationName, Rooms, checkInDate, checkOutDate, bill));
				else 
					Reservations.add(new AdvancedPurchaseReservation(ReservationNumber, ReservationName, Rooms, checkInDate, checkOutDate, bill));
	    	}
	        lineNumber++;
	    }
	    bufferedReader.close();
	}
}
