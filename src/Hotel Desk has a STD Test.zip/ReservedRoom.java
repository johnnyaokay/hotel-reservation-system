
public class ReservedRoom {
	private Room room;
	private int noOfAdults;
	private int noOfChildren;
	private Boolean breakfastIncluded = false;
	
	public ReservedRoom(Room room, int noOfAdults, int noOfChildren) {
		this.room = room;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
	}

	public Room getRoom() {
		return room;
	}

	public Boolean getBreakfastIncluded() {
		return breakfastIncluded;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}
	
	
}
	
