import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ReservationSystemInterface {
	private Scanner in;

	public ReservationSystemInterface() {
		in = new Scanner(System.in);
	}
	
	private int getIntFromInput() {
		while (!in.hasNextInt()) {
			   in.next();
			   System.out.println("Please enter an Integer");
		}
		return in.nextInt();
	}
	
	private String getDateFromInput() {
		String date = in.nextLine();
		return "";
	}
	
	private void Login() {
		
	}

	public void run(ReservationSystem system) throws IOException {
		system.loadHotelData();
		//system.loadReservationData();
		
		HashMap<String, String[]> Methods = new HashMap<String, String[]>();
		Methods.put("Customer", new String[]{"Reservation", "Cancellation"});
		Methods.put("Hotel Desk Administrator", new String[]{"Reservation", "Cancellation", "Check-In", "Check-Out"});
		Methods.put("Supervisor", new String[]{"Reservation", "Cancellation", "Check-In", "Check-Out", "Apply Discount", "View Data"});
		
	
		System.out.println("Login: (1)Customer (2)Hotel Desk Administrator (3)Supervisor");
		String user = "";
		int input = getIntFromInput();
		if(input == 1) user = "Customer";
		if(input == 2) user = "Hotel Desk Administrator";
		if(input == 3) user = "Supervisor";
		
		String[] Commands = Methods.get(user);
		HashMap<Integer, String> indexes = new HashMap<Integer, String>();
		int position = 1;
		for(int i = 0; i < Commands.length; i++) {
			indexes.put((position), Commands[i]);
			System.out.print("(" + position + ")" + Commands[i] + " ");
			position++;
		}
		System.out.println();
				
		String chosenCommand = indexes.get(getIntFromInput());
		
		if(chosenCommand.equals("Reservation")) {
			ArrayList<ReservedRoom> chosenRooms = new ArrayList<>();
			double totalCost = 0;
			
			System.out.println("Enter check-in date after: " + new ReservationDate(LocalDate.now()));
			ReservationDate checkIn = new ReservationDate(in.next());
			System.out.println(checkIn);
			System.out.println("Enter check-out date before: " + new ReservationDate(checkIn.getDate().plusDays(30)));
			ReservationDate checkOut = new ReservationDate(in.next());
			System.out.println("How many rooms would you like to reserve?");
			int noOfRooms = in.nextInt();
			
			for(int i = 1; i < noOfRooms + 1; i++) {
				System.out.println("How many adults for room " + i + "? (min: " + system.getMinAdults() + ") " + "(max: " + system.getMaxAdults() + ")");
				int noOfAdults = in.nextInt();
				System.out.println("How many children for room " + i + "? (min: " + system.getMinChildren() + ") " + "(max: " + system.getMaxChildren() + ")");
				int noOfChildren = in.nextInt();
				System.out.println("Choose a room (" + i + "/" + noOfRooms + "):" );
				Room chosenRoom = system.getRoomChoices(noOfAdults, noOfChildren, checkIn, checkOut);
				
				int noOfNights = checkIn.getNoOfNights(checkOut);
				double[] rates = chosenRoom.getRates();
				int currentDay = checkIn.getWeekday();
				int price = 0;
				for(int j = 0; j < noOfNights; j++) {
					price += rates[currentDay];
					currentDay++;
					if(currentDay == 7) currentDay = 0;
				}
				totalCost += price;
				chosenRooms.add(new ReservedRoom(chosenRoom, noOfAdults, noOfChildren));
			}
			
			in.nextLine();
			System.out.println("Enter reservation name:");
			String name = in.nextLine();
			
			System.out.println("Enter reservation type: (A)Standard (B)Advanced Purchased");
			String reservationType = in.nextLine();
			
			Bill bill = new Bill(totalCost);
			if(reservationType.equals("A")) bill.applyDiscount(0.05);
			System.out.println("Total cost is: " + totalCost);
			System.out.println("A deposit of: " + totalCost * 0.20 + " is required to reserve the room");
			System.out.println("(A)Pay (B)Cancel");
			String command = in.nextLine();
			if(command.equals("A")) {
				
				if(reservationType.equals("A")) 
					system.addReservation(new StandardReservation(name, chosenRooms, checkIn, checkOut, bill));
				else 
					system.addReservation(new AdvancedPurchaseReservation(name, chosenRooms, checkIn, checkOut, bill));
				System.out.println("Reservation succesfully made!");
			}
		} 
		
		else if(chosenCommand.equals("Cancellation")) {
			System.out.println("Enter Reservation Number");
			Reservation currentReservation = system.getReservation(in.nextLine());
			if(currentReservation != null) {
				currentReservation.cancel();
			} else {
				System.out.println("Invalid Reservation Number");
			}
		}
		
		else if(chosenCommand.equals("Check-In")) {
			System.out.println("Enter Reservation Number");
			Reservation currentReservation = system.getReservation(in.nextLine());
			if(currentReservation != null) {
				currentReservation.checkIn();
			} else {
				System.out.println("Invalid Reservation Number");
			}
		}
		
		else if(chosenCommand.equals("Check-Out")) {
			System.out.println("Enter Reservation Number");
			Reservation currentReservation = system.getReservation(in.nextLine());
			if(currentReservation != null) {
				currentReservation.checkOut();
			} else {
				System.out.println("Invalid Reservation Number");
			}
		}
		
		else if(chosenCommand.equals("Apply Discount")) {
			System.out.println("Enter Discount");
			Double discount = in.nextDouble();
			System.out.println("Enter Reservation Number");
			Reservation currentReservation = system.getReservation(in.nextLine());
			if(currentReservation != null) {
				currentReservation.getBill().applyDiscount(discount);
			} else {
				System.out.println("Invalid Reservation Number");
			}
		}
		
		else if(chosenCommand.equals("View Data")) {
			System.out.println("v");
		}
	}
}
