import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Reservation {
	protected String ReservationNo;
	private String ReservationName;
	protected String ReservationType;
	private ArrayList<ReservedRoom> reservedRooms = new ArrayList<>();
	private Bill bill;
	private ReservationDate checkInDate;
	private ReservationDate checkOutDate;
	private boolean checkedIn;
	private boolean checkedOut;

	public Reservation(String ReservationName, ArrayList<ReservedRoom> chosenRooms, ReservationDate checkIn, ReservationDate checkOut, Bill bill, String ReservationType) throws IOException{
		ReservationNo = ReservationName.substring(0, 3) + System.currentTimeMillis();
		this.ReservationName = ReservationName;
		this.reservedRooms = chosenRooms;
		this.checkInDate = checkIn;
		this.checkOutDate = checkOut;
		this.bill = bill;
		this.ReservationType = ReservationType;
		writeToCSV(); //change this to try catch
	}
	
	public Reservation(String ReservationNo, String ReservationName, ArrayList<ReservedRoom> chosenRooms, ReservationDate checkIn, ReservationDate checkOut, Bill bill, String ReservationType) throws IOException{
		this.ReservationNo = ReservationNo;
		this.ReservationName = ReservationName;
		this.reservedRooms = chosenRooms;
		this.checkInDate = checkIn;
		this.checkOutDate = checkOut;
		this.bill = bill;
		this.ReservationType = ReservationType;
		writeToCSV(); //change this to try catch
	}
	
	public String getReservationNumber() {
		return ReservationNo;
	}
	
	public Bill getBill() {
		return bill;
	}
	
	public void writeToCSV() throws IOException {
		//Use Date class or method to count days because this will error for months and that
		int noOfNights = checkInDate.getNoOfNights(checkOutDate);
		
		FileWriter csvWriter = new FileWriter("src/Reservation Information.csv", true);
		csvWriter.append(ReservationNo + "," + ReservationName + "," + ReservationType + "," + checkInDate + "," + noOfNights + "," + reservedRooms.size() + ",");
		for(int i = 0; i < reservedRooms.size(); i++) {
			if(i > 0) csvWriter.append(",,,,,,");
			ReservedRoom currentRoom = reservedRooms.get(i);
			String occupancy = currentRoom.getNoOfAdults() + "+" + currentRoom.getNoOfChildren();
			csvWriter.append(currentRoom.getRoom().getRoomType() + "," + occupancy + "," + currentRoom.getBreakfastIncluded() + "," + bill.getTotal() + "," + bill.getDeposit());
			csvWriter.append("\n");
			
		}
		csvWriter.flush();
		csvWriter.close();
	}
	
	public void checkIn() throws IOException {
		checkedIn = true;
		FileWriter csvWriter = new FileWriter("src/Hotel Stay & Cancellation Information.csv", true);
		csvWriter.append(new ReservationDate(LocalDate.now()) + "," + ReservationNo + "," + ReservationType + "," + "Check-In" + ",");
		csvWriter.flush();
		csvWriter.close();
	}
	
	public void checkOut() throws IOException {
		checkedOut = true;
		FileWriter csvWriter = new FileWriter("src/Hotel Stay & Cancellation Information.csv", true);
		csvWriter.append(new ReservationDate(LocalDate.now()) + "," + ReservationNo + "," + ReservationType + "," + "Check-Out" + ",");
		csvWriter.flush();
		csvWriter.close();
	}
	
	public void cancel() throws IOException {
		FileWriter csvWriter = new FileWriter("src/Hotel Stay & Cancellation Information.csv", true);
		csvWriter.append(new ReservationDate(LocalDate.now()) + "," + ReservationNo + "," + ReservationType + "," + "Cancellation" + ",");
		csvWriter.flush();
		csvWriter.close();
	}

}
