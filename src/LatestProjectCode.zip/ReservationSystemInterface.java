import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ReservationSystemInterface {
	private Scanner in;

	public ReservationSystemInterface() {
		in = new Scanner(System.in);
	}

	public void run(ReservationSystem system) throws IOException {
		system.loadData();

		boolean more = true;

		while (more) {
			System.out.println("Login: (A)Customer (B)Hotel Desk Administrator (C)Supervisor (D)Quit");
			String command = in.nextLine();

			// Customer
			if (command.equals("A")) {
				System.out.println("(A)Make a reservation (B)Cancel a reservation");
				command = in.nextLine();
				if (command.equals("A")) {
					ArrayList<ReservedRoom> chosenRooms = new ArrayList<>();
					double totalCost = 0;
					
					System.out.println("Enter check-in date (dd/mm/yyyy):");
					ReservationDate checkIn = new ReservationDate(in.nextLine());
					System.out.println(checkIn);
					System.out.println("Enter check-out date (dd/mm/yyyy):");
					ReservationDate checkOut = new ReservationDate(in.nextLine());
					System.out.println("How many rooms would you like to reserve?");
					int noOfRooms = in.nextInt();
					
					for(int i = 1; i < noOfRooms + 1; i++) {
						System.out.println("How many adults for room " + i + "? (min: " + system.getMinAdults() + ") " + "(max: " + system.getMaxAdults() + ")");
						int noOfAdults = in.nextInt();
						System.out.println("How many children for room " + i + "? (min: " + system.getMinChildren() + ") " + "(max: " + system.getMaxChildren() + ")");
						int noOfChildren = in.nextInt();
						System.out.println("Choose a room (" + i + "/" + noOfRooms + "):" );
						Room chosenRoom = system.getRoomChoices(noOfAdults, noOfChildren, checkIn, checkOut);
						
						int noOfNights = checkIn.getNoOfNights(checkOut);
						double[] rates = chosenRoom.getRates();
						int currentDay = checkIn.getWeekday();
						int price = 0;
						for(int j = 0; j < noOfNights; j++) {
							price += rates[currentDay];
							currentDay++;
							if(currentDay == 7) currentDay = 0;
						}
						totalCost += price;
						chosenRooms.add(new ReservedRoom(chosenRoom, noOfAdults, noOfChildren, price));
					}
					
					in.nextLine();
					System.out.println("Enter reservation name:");
					String name = in.nextLine();
					
					System.out.println("Enter reservation type: (A)Standard (B)Advanced Purchased");
					String reservationType = in.nextLine();
					
					Bill bill = new Bill(totalCost);
					if(reservationType.equals("A")) bill.applyDiscount(0.05);
					System.out.println("Total cost is: " + totalCost);
					System.out.println("A deposit of: " + totalCost * 0.20 + " is required to reserve the room");
					System.out.println("(A)Pay (B)Cancel");
					command = in.nextLine();
					if(command.equals("A")) {
						
						if(reservationType.equals("A")) 
							system.addReservation(new StandardReservation(name, chosenRooms, checkIn, checkOut, bill));
						else 
							system.addReservation(new AdvancedPurchaseReservation(name, chosenRooms, checkIn, checkOut, bill));
						System.out.println("Reservation succesfully made!");
					}
					//pay deposit
					
					//Pay first before this
					
					
					// ArrayList<Room> chosenRooms = new ArrayList<>()

					// Enter check-in date
					// Date check-in = new Date()
					// Enter check-out date
					// Date check-out = new Date()
					// Enter how many rooms
					// Integer NoOfRooms = rooms

					// for loop NoOfRooms times
						// ask how many adults (min(hotels.getMinAdults) same with max)
						// ask how many children (min(hotels.getMinChildren) same with max)
						// Integer noOfAdults
						// Integer noOfChildren
						// List all rooms that match min/max adult/child and are available on that date
						// List rooms in format: hotelType | roomType | price
						// user picks a room
						// chosenRooms.add(new Room(roomType, noOfAdults, noOfChildren, price)
					//

					// Enter reservation name
					// String reservationName

					// Reservations.add(new Reservation(name, chosenRooms, check-in, check-out));
				} else if (command.equals("B")) {
					System.out.println("Enter Reservation Number");
					Reservation currentReservation = system.getReservation(in.nextLine());
					if(currentReservation != null) {
						currentReservation.cancel();
					} else {
						System.out.println("Invalid Reservation Number");
					}
				}

			}

			// Hotel Desk Administrator
			else if (command.equals("B")) {
				System.out.println("(A)Make a reservation for a customer (B)Cancel a reservation for a customer (C)Check-In (D)Check-Out");
				if (command.equals("A")) {
					
				} else if (command.equals("B")) {
					// Cancellation Function
				}
				else if (command.equals("C")) {
					System.out.println("Enter Reservation Number");
					Reservation currentReservation = system.getReservation(in.nextLine());
					if(currentReservation != null) {
						currentReservation.checkIn();
					} else {
						System.out.println("Invalid Reservation Number");
					}
				}
				else if (command.equals("D")) {
					System.out.println("Enter Reservation Number");
					Reservation currentReservation = system.getReservation(in.nextLine());
					if(currentReservation != null) {
						currentReservation.checkOut();
					} else {
						System.out.println("Invalid Reservation Number");
					}
				}
			}

			// Supervisor
			else if (command.equals("C")) {
				System.out.println("(A)Apply Discount");
				if (command.equals("A")) {
					System.out.println("Enter Discount");
					Double discount = in.nextDouble();
					System.out.println("Enter Reservation Number");
					Reservation currentReservation = system.getReservation(in.nextLine());
					if(currentReservation != null) {
						currentReservation.getBill().applyDiscount(discount);
					} else {
						System.out.println("Invalid Reservation Number");
					}
				}
				//get data
			}

			// Quit
			else if (command.equals("D")) {
				more = false;
			}
		}
	}
}
