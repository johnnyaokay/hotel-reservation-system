private ReservationDate getDateFromInput(String inOrOut, LocalDate checkInTime) {
		boolean checkIn = false,checkOut = false;
		if (inOrOut.equals("checkin")) checkIn = true; 
		if (inOrOut.equals("checkout")) checkOut = true; 
		
		if (checkIn) { 
			System.out.println("Enter check-in date after " + new ReservationDate(checkInTime));
		} else if (checkOut) { 
			System.out.println("Enter check-out date before " + new ReservationDate(checkInTime.plusDays(30)));
		}
		ReservationDate d = null;
		boolean ok = false;
		while (!ok) {
			String date = in.next();		
			try {
				d = new ReservationDate(date);
				if (checkIn) { 
					if (d.getDate().isBefore(checkInTime)) System.out.print("Check-in can not be before current time... Enter date again: "); 
					else ok = true; 
					
				} else if (checkOut) { 
					if (d.getDate().isAfter(checkInTime.plusDays(30))) System.out.print("Check-out can not be over 30 days after check-in... Enter date again: "); 
					else ok = true;				
				}
				
			} catch (DateTimeException e) {
				System.out.print("Date Not Valid... Try entering it again: ");

			} catch (NumberFormatException e) {
				System.out.println("Please enter the date in format dd/mm/yyyy... Try entering it again: ");
			}
		}
	
		return d;
	}
public Room getRoomChoices(int noOfAdults, int noOfChildren, ReservationDate checkIn, ReservationDate checkOut) {
		HashMap<Integer, Room> roomIndexes = new HashMap<Integer, Room>();
		int day = checkIn.getWeekday();
		int roomCount = 0;
		System.out.printf("No. %-7s %-17s %s\n", "Hotel", "Room Type", "Cost");
		System.out.println("-------------------------------------");
		for(int i = 0; i < Hotels.size(); i++) {
			ArrayList<Room> hotelRooms = Hotels.get(i).getRooms();
			for(int j = 0; j < hotelRooms.size(); j++) {
				Room room =  hotelRooms.get(j);
				if(room.RoomsAvailable() && room.canOccupy(noOfAdults, noOfChildren)){
					roomCount++;
					System.out.printf("(%d) %-25s %.2f\n",roomCount, room,getRoomPrice(room, checkIn, checkOut));
					roomIndexes.put(roomCount, room);
				}
			}
		}
		int command = in.nextInt();
		return roomIndexes.get(command);
	}
Inside run() > inside if (chosenCommand.Equals(Reservation) thing
if (chosenCommand.equals("Reservation")) {
			ArrayList<ReservedRoom> chosenRooms = new ArrayList<>();
			double totalCost = 0;
	
			LocalDate time = LocalDate.now(); 
			
			ReservationDate checkIn = getDateFromInput("checkin", time);			
			ReservationDate checkOut = getDateFromInput("checkout", time);
			
			System.out.println("How many rooms would you like to reserve?");
			int noOfRooms = in.nextInt();

			for (int i = 1; i < noOfRooms + 1; i++) {
				System.out.println("How many adults for room " + i + "? (min: " + system.getMinAdults() + ") "
						+ "(max: " + system.getMaxAdults() + ")");
				int noOfAdults = in.nextInt();
				System.out.println("How many children for room " + i + "? (min: " + system.getMinChildren() + ") "
						+ "(max: " + system.getMaxChildren() + ")");
				int noOfChildren = in.nextInt();
				System.out.println("Choose a room (" + i + "/" + noOfRooms + "):");
				Room chosenRoom = system.getRoomChoices(noOfAdults, noOfChildren, checkIn, checkOut);
				totalCost += system.getRoomPrice(chosenRoom, checkIn, checkOut);
				chosenRooms.add(new ReservedRoom(chosenRoom, noOfAdults, noOfChildren));
			}

			System.out.println("Enter reservation name:");
			String name = in.next();

			System.out.println("Enter reservation type: (A)Standard (B)Advanced Purchased");
			String reservationType = in.next();

			Bill bill = new Bill(totalCost);
			if (reservationType.equals("A"))
				bill.applyDiscount(0.05);
			System.out.println("Total cost is: " + totalCost);
			System.out.println("A deposit of: " + totalCost * 0.20 + " is required to reserve the room");
			System.out.println("(A)Confirm (B)Cancel");
			String command = in.next();
			if (command.equals("A")) {

				if (reservationType.equals("A"))
					system.addReservation(new StandardReservation(name, chosenRooms, checkIn, checkOut, bill));
				else
					system.addReservation(new AdvancedPurchaseReservation(name, chosenRooms, checkIn, checkOut, bill));
				System.out.println("Reservation succesfully made!");
			}
		}

while (!in.hasNextInt()) {
	   in.next();
	   System.out.println("Please enter an Integer");
}
return in.nextInt();