import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

abstract class Analytics {
	HashMap <String, double[]> data = new HashMap<>();
	
	
	public void main() throws IOException { 
		BufferedReader bufferedReader = null;
	
		try {
			bufferedReader = new BufferedReader(new FileReader("src/hotelStays.csv"));
		} catch (FileNotFoundException e) {
			System.out.println("Error. File Not Found"); 
		} 
		
		int lineNumber = 1;  
		String line = null; 
		while ((line = bufferedReader.readLine()) != null) { 
			if (lineNumber > 1) { 
				String[] values = line.split(","); 
				
			}
		}
		
	}
	
	private void writeCSV() {
		FileWriter csvWriter = new FileWriter("src/Analytics.csv");
		ArrayList<Hotel> Hotels = ReservationSystem.getHotel();
		for(int i = 0; i < Hotels.size(); i++) {
			ArrayList<Room> hotelRooms = Hotels.get(i).getRooms();
			for(int j = 0; j < hotelRooms.size(); j++) {
				Room room =  hotelRooms.get(j);
				if(room.RoomsAvailable() && room.canOccupy(noOfAdults, noOfChildren)){
					roomCount++;
					System.out.printf("%2d) %-25s %.2f\n",roomCount, room,getRoomPrice(room, checkIn, checkOut));
					roomIndexes.put(roomCount, room);
				}
			}
		}
		csvWriter.append("Hotel");
		csvWriter.flush();
		csvWriter.close();
	}
	
	
	public void monthlyAnalytics(int month) { 
		
	}
	
	public void dailyAnalytics(LocalDate date) throws IOException { 
		BufferedReader bufferedReader = null;
		
		try {
			bufferedReader = new BufferedReader(new FileReader("src/hotelStays.csv"));
		} catch (FileNotFoundException e) {
			System.out.println("Error. File Not Found"); 
		} 
		
		int lineNumber = 1;  
		String line = null; 
		while ((line = bufferedReader.readLine()) != null) { 
			if (lineNumber > 1) { 
				String[] values = line.split(",");
				ReservationDate d = new ReservationDate (values[0]); 
				if (d.getDate().equals(date)) { // its the requested day
					String roomName = values[2];
					int noOfRooms = Integer.parseInt(values[3]);
					String state = values[6];
					double total = Double.parseDouble(values[4]);
					for(int i = 0; i < noOfRooms; i++) {
						if(!data.containsKey(roomName)) data.put(roomName, null);
						double[] stats = data.get(roomName);
						if(state.equals("Cancelled")) {
							stats[1]++;
						} else {
							stats[0]++;
						}
						stats[2] = total;
						if(noOfRooms > 1) lineNumber++;
					}
				}
			}
		}
	}
	
	public void intervalAnalytics(LocalDate start, LocalDate end) { 
		
	}
	
	private void roomMonthlyOccupancy() { 
		
	}

	private void hotelMonthlyOccupancy() { 
		
	}
}